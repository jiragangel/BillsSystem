'use strict';

const db = require(__dirname + '/../lib/mysql');

exports.viewBills = (req, res, next) => {
	const queryline = 'select * from BILL where ' + req.query.key + '="' + req.query.value + '"';
	console.log(queryline);
	db.query(queryline,[],(err, result) => {
		res.send(result);
	})
};
exports.addBills=(req,res,next)=>{
	const queryline='insert into BILL values ' + req.body.billno +','+req.body.status +','+req.body.type +','+req.body.title +','+
					req.body.summarydesc +','+req.body.content +','+req.body.primarycommittee +','+req.body.scope +','+
					req.body.secondarycommittee +','+'1'+',';
	console.log(queryline);
	db.query(queryline,[],(err,result)=>{
		res.send(result);
	});
};
exports.deleteBills=(req,res,next)=>{
	const queryline='delete from BILL where Billno="'+req.body.billno+'"';
	//const queryline1='IF NOT Senator_flag = NULL THEN delete from SENATOR_FILES where'+req.query.billno
	db.query(queryline,[],(err,result)=>{
		res.send(result);
	})
}

exports.updateBills = (req, res, next) => {
	const queryline = 'update BILL set ' + req.body.key + '="' + req.body.value + '" where Billno="' + req.body.billno + '"';
	console.log(req.body);
	db.query(queryline, [], (err, result) => {
		res.send(result);
	});
}

exports.mainPage = (req, res, next) => {
	res.send("Welcome to Home Page");
}
